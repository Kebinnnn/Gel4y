<h2 align="center">Gel4y Mini Shell Backdoor</h2>

<p align="center">
	<img src="https://img.shields.io/badge/PHP-7.4.3-yellowgreen">
	<img src="https://img.shields.io/badge/LICENSE-MIT-orange">
	<img src="https://img.shields.io/badge/Version-1.1-red">
</p>

Summary
----------

Gel4y Webshell is a backdoor built using the PHP programming language in a stealth mode that can bypass server security. Each function has been converted into hex code so that it can penetrate the WAF server system.

Features
--------

* Multiple File Upload
* Create Folder and File
* File Download
#### Bypassed
* 403 Forbidden
* 406 Not Acceptable
* Imunify360

Preview
-------

![SCREENSHOT](https://raw.githubusercontent.com/22XploiterCrew-Team/Gel4y-Mini-Shell-Backdoor/main/preview.png)

### #IIIIIHHH_GASUKA_GELAAY
